package com.baseclasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import java.time.Duration;

import static java.sql.DriverManager.getDriver;

public class CodeBase {

        // public WebDriver driver;
        protected static ThreadLocal<WebDriver> driver = new ThreadLocal<>();


        @BeforeTest(alwaysRun = true)
        @SuppressWarnings("unchecked")
        public void setUp() throws Exception {
                ChromeOptions options = new ChromeOptions();
                options.addArguments("start-maximized");
                DesiredCapabilities capabilities = new DesiredCapabilities();
                capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                capabilities.setCapability("nativeWebTap","false");
                capabilities.setCapability("browserstack.safari.allowAllCookies", "true");
                driver.set(new ChromeDriver(options));
                driver.get().get("http://yourpersonahome.com");
                driver.get().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
                driver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
                System.out.println("Launching the main website " + driver.get().getTitle());
                driver.get().manage().window().maximize();
                
                //WebElement acceptCookiesButton = driver.get().findElement(By.xpath("//*[contains(text(), 'Accept')]"));
                WebDriverWait wait = new WebDriverWait(driver.get(), Duration.ofSeconds(30));
                wait.until(ExpectedConditions.elementToBeClickable(driver.get().findElement(By.xpath("//*[contains(text(), 'Accept')]"))));

                WebElement acceptCookiesButton = driver.get().findElement(By.xpath("//*[contains(text(), 'Accept')]"));       
                acceptCookiesButton.click();
        }

        @AfterTest(alwaysRun = true)
        public void tearDown() throws Exception {
                if (driver.get() != null) {
                         driver.get().quit();
                }
        }


}
