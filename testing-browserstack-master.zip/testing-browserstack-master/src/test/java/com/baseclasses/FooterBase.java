package com.baseclasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;


public class FooterBase extends ColorBase{
    SoftAssert softAssert = new SoftAssert();

    public void test_the_footer_section_the_text_and_the_copyright () {
        WebElement footersection = driver.get().findElement(By.xpath("//*[@class=\"Section Section--main Footer__section\"]"));
        //verifying footer section is present
        softAssert.assertTrue(footersection.isDisplayed());
        WebElement footertextele = driver.get().findElement(By.xpath("(//*[@class='u-text-small Footer__copyright-p'])[1]"));
        String footertext = footertextele.getText();
        //verify the footer text and copyright
        softAssert.assertEquals("Persona it's your home – registered trade mark of Home Group Limited (charitable registered society no. 22981R). Home Group Developments Limited (registered in England Company no. 4664018) is a subsidiary of Home Group Limited.  All copyrights and other intellectual property rights subsisting in this website and its contents are the property of  Home Group, (including, but not limited to, all texts, documents, brochures, graphics, logos, trademarks, product names, images, website design and layouts). Any reproduction, transfer, modification, utilisation or publication of the website or its contents in its whole or part in any form, (including, but not limited to, framing, incorporation into other websites or other publications) for any public and/or commercial purpose is prohibited without the prior written consent of Home Group.", footertext);
        WebElement footertext2ele = driver.get().findElement(By.xpath("(//*[@class='u-text-small Footer__copyright-p Footer__copyright-p--margin-large'])[1]"));
        String footertext2 = footertext2ele.getText();
        softAssert.assertEquals("Please note that all images are for illustrative purposes only and may feature similar Persona Homes developments or CGIs.", footertext2);
        WebElement footertext3ele = driver.get().findElement(By.xpath("(//*[@class='u-text-small Footer__copyright-p'])[2]"));
        String footertext3 = footertext3ele.getText();
        //get the current year
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String currentdate = dtf.format(now);
        String currentyear = currentdate.substring(0, 4);
        System.out.println("current year is - " + currentyear);
        String expectedcopyright = ("© Home Group ").concat(currentyear);
        //verify the copyright along with the current year
        softAssert.assertEquals(footertext3, expectedcopyright);
        softAssert.assertAll();
    }
    public void test_the_footer_section_and_the_contact_us_section () {
        WebElement footertextcontactusele = driver.get().findElement(By.xpath("(//*[@class='h4 Footer__nav-title'])[1]"));
        String footertextcontactus = footertextcontactusele.getText();
        //verify the contact us text, meet our sales text and meet our sales href
        softAssert.assertEquals("Contact us", footertextcontactus);
        WebElement meetoursalesEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Footer__nav-link'])[1]"));
        String meetoursalesText = meetoursalesEle.getText();
        softAssert.assertEquals("Meet our sales hosts dedicated to each of our developments.", meetoursalesText);
        String meetoursalesHref = meetoursalesEle.getAttribute("href");
        softAssert.assertEquals("https://yourpersonahome.com/get-in-touch", meetoursalesHref);
        softAssert.assertAll();
    }
    public void test_the_footer_section_and_the_legal_stuff_section () {
        //verify the options in the legal stuff
        WebElement legalstuffEle = driver.get().findElement(By.xpath("(//*[@class='h4 Footer__nav-title'])[2]"));
        String legalstuffText = legalstuffEle.getText();
        softAssert.assertEquals("Legal stuff", legalstuffText);
        WebElement tancEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Footer__nav-link'])[2]"));
        String tancText = tancEle.getText();
        softAssert.assertEquals("Persona terms & conditions", tancText);
        String tandcHref = tancEle.getAttribute("href");
        softAssert.assertEquals("https://yourpersonahome.com/legal/terms-and-conditions", tandcHref);
        WebElement cookiepolicyEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Footer__nav-link'])[3]"));
        String cookiepolicyText = cookiepolicyEle.getText();
        softAssert.assertEquals("Cookie policy", cookiepolicyText);
        String cookiepolicyHref = cookiepolicyEle.getAttribute("href");
        softAssert.assertEquals("https://yourpersonahome.com/legal/cookie-policy", cookiepolicyHref);
        WebElement privacypolicyEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Footer__nav-link'])[4]"));
        String privacypolicyText = privacypolicyEle.getText();
        softAssert.assertEquals("Privacy policy", privacypolicyText);
        String privacypolicyHref = privacypolicyEle.getAttribute("href");
        softAssert.assertEquals("https://yourpersonahome.com/legal/privacy-policy", privacypolicyHref);
        softAssert.assertAll();
    }
    public void test_the_footer_section_and_the_get_in_touch_section () {
        //verify the options in the get in touch
        WebElement getintouchEle = driver.get().findElement(By.xpath("(//*[@class='h4 Footer__nav-title'])[3]"));
        String getintouchText = getintouchEle.getText();
        softAssert.assertEquals("Get in touch", getintouchText);
        WebElement freephoneEle = driver.get().findElement(By.xpath("(//*[@class='List__item'])[1]"));
        String freephoneText = freephoneEle.getText();
        softAssert.assertEquals("Freephone: 0808 196 1532", freephoneText);
        WebElement emailusEle = driver.get().findElement(By.xpath("(//*[@class='List__item'])[2]"));
        String emailusText = emailusEle.getText();
        softAssert.assertEquals("Email us: contactus@yourpersonahome.com", emailusText);
        WebElement freephonenumberEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Nav__link--bold'])[1]"));
        String freephonenumberHref = freephonenumberEle.getAttribute("href");
        softAssert.assertEquals("tel:0808 196 1532", freephonenumberHref);
        WebElement contactusemailEle = driver.get().findElement(By.xpath("(//*[@class='Nav__link Nav__link--bold'])[2]"));
        String emailusHref = contactusemailEle.getAttribute("href");
        softAssert.assertEquals("mailto:contactus@yourpersonahome.com?subject=Persona%20Homes%20Web%20Enquiry&body=If%20you%20are%20interested%20in%20a%20Persona%20home%20and%20would%20like%20us%20to%20help%20you%20find%20the%20home%20that%20suits%20you%2C%20please%20enter%20your%20details%20and%20we%20will%20get%20back%20to%20you.%0A%0AFirst%20name%3A%0A%0ASurname%3A%0A%0AEmail%20Address%3A%0A%0AContact%20Number%3A%0A%0AEnquiry%3A", emailusHref);
        softAssert.assertAll();
    }
    public void test_the_footer_section_and_the_four_icons () {
        //verify the four icons are present
        WebElement fbicon = driver.get().findElement(By.xpath("(//*[@class=\"Nav__link Footer__social-link\"])[1]"));
        softAssert.assertTrue(fbicon.isDisplayed());
        WebElement twittericon = driver.get().findElement(By.xpath("(//*[@class=\"Nav__link Footer__social-link\"])[2]"));
        softAssert.assertTrue(twittericon.isDisplayed());
        WebElement igcon = driver.get().findElement(By.xpath("(//*[@class=\"Nav__link Footer__social-link\"])[3]"));
        softAssert.assertTrue(igcon.isDisplayed());
        WebElement inicon = driver.get().findElement(By.xpath("(//*[@class=\"Nav__link Footer__social-link\"])[4]"));
        softAssert.assertTrue(inicon.isDisplayed());
        System.out.println("Footer Verified");
        softAssert.assertAll();
    }

}



