package com.browserstack;

import com.baseclasses.FormBase;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class EnquiryFormDevelopmentTest extends FormBase {
    FormBase fb = new FormBase();
    SoftAssert softAssert = new SoftAssert();
    @Test(priority = 0)
    public void Go_To_Yorkshire_MeauxRise_Verify_The_Page_Then_Click_ArrangeAnAppointment() {
        WebElement DevelopmentNav = driver.get().findElement(By.xpath("//*[contains(text(), 'Developments')]"));
        DevelopmentNav.click();
        DevelopmentNav.click();

        //Creating the JavascriptExecutor interface object by Type casting
        JavascriptExecutor js = (JavascriptExecutor)driver.get();
        //Locate and click the Yorkshire header in the dropdown Nav Menu
        WebElement YorkshireNav = driver.get().findElement(By.xpath("//*[contains(text(), 'Yorkshire')]"));
        js.executeScript("arguments[0].click();", YorkshireNav);
        //YorkshireNav.click();
        //Locate and click the Meaux Rise header in the dropdown Nav Menu
        WebElement MeauxRise = driver.get().findElement(By.xpath("//*[contains(text(), 'Meaux Rise')]"));
        js.executeScript("arguments[0].click();", MeauxRise);
        //MeauxRise.click();

        //Wait until the 'description' field is available - this performs a wait which could be milliseconds
        WebDriverWait wait = new WebDriverWait(driver.get(), Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("description")));


        //Find the header of the page, in this instance Meaux Rise & get the text to store it.
        WebElement MeauxRiseCheck = driver.get().findElement(By.xpath("(//*[contains(text(), 'Meaux Rise')])[5]"));
        String Development = MeauxRiseCheck.getText();

        //Find the arrange an appointment button then click it.
        WebElement ArrangeAnAppointment = driver.get().findElement(By.xpath("(//*[contains(text(),'Arrange an appointment')])[2]"));
        ArrangeAnAppointment.click();

        //Perform a wait until the firstname box is available.
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("firstname")));

        //Find the breadcrumb text of Meaux Rise & store it.
        WebElement DevelopmentBreadCrumb = driver.get().findElement(By.xpath("(//*[contains(text(),'Meaux Rise')])[3]"));
        String DevelopmentBreadCrumbText = DevelopmentBreadCrumb.getText();

        //Confirm that the developments stored are correct
        softAssert.assertEquals(DevelopmentBreadCrumbText, Development);

        //print out the current development areas into the console so that it can be verified for new pages.
        System.out.println(Development);
        System.out.println(DevelopmentBreadCrumbText);

        softAssert.assertAll();
    }

    @Test(priority = 1)
    public void EnterFirstname() {
        fb.EnterFirstName();
    }

    @Test(priority = 2)
    public void EnterSurname() {
        fb.EnterSurname();
    }

    @Test(priority = 3)
    public void EnterEmail() {
        fb.EnterEmail();
    }

    @Test(priority = 4)
    public void EnterContact() {
        fb.Fill_in_ContactField();
    }

    @Test(priority = 5)
    public void EnterPostcode() {
        fb.Fill_In_PostCode();
    }

    @Test(priority = 6)
    public void FilterThroughDropdowns() {
        fb.FilterThroughDropdowns();
    }

    @Test(priority = 7)
    public void Complete_CheckBoxes() {
        fb.Check_Checkboxes();
    }

    @Test(priority = 8)
    public void Declaration_Boxes_Check() {
        fb.Click_Declaration();
    }

    @Test(priority = 9)
    public void Check_Submit_Button() {
        fb.Click_Get_Back_To_Me();
    }

}
